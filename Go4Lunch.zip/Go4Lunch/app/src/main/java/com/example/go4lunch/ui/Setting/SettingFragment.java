package com.example.go4lunch.ui.Setting;

import androidx.fragment.app.Fragment;

public class SettingFragment extends Fragment {
}
